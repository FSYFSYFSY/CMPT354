const { name } = require('ejs');
const express = require('express')
const path = require('path')
const PORT = process.env.PORT || 5000
const app = express()
const { Pool } = require('pg');
const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  // "postgres://postgres:@localhost/cmpt354"
  ssl: {
    rejectUnauthorized: false
  }
});
app.use(express.json())
  app.use(express.urlencoded({ extended: false }))
app.use(express.static(path.join(__dirname, 'public')))
app.set('views', path.join(__dirname, 'views'))
app.set('view engine', 'ejs')
app.get('/', (req, res) => res.render('pages/index'))
app.get('/restaurant', (req, res) => res.render('pages/restaurant'))
app.post('/find_count', async(req,res)=>{
  var nof = req.body.nof
  pool.query(`select field, count(*) AS c from manager group by field`, (err,result)=>{
    if(err){
      res.send(`error finding field <a href=\'/'>click to go back to home page</a>`)
    }
    else{
      var res_list = {data: result.rows}
      res.render('pages/output_count',res_list)
    }
  })
})
app.post('/updatecus', async(req,res)=>{
  var cusid = req.body.cust_id
  var cusname = req.body.cust_name
  pool.query(`UPDATE customer set name = '${cusname}' WHERE cid = '${cusid}'`, (err,result)=>{
    if(err){
      res.send(`error inserting customer <a href=\'/'>click to go back to home page</a>`)
    }
    else{
      res.send(`succeed inserting customer <a href=\'/customer'>click to go back to customer page</a>`)
    }
  })
})
app.post('/insertcus', async(req,res)=>{
  var cusid = req.body.cust_id
  var cusname = req.body.cust_name
  pool.query(`INSERT INTO customer (cid,name) VALUES ('${cusid}', '${cusname}')`, (err,result)=>{
    if(err){
      res.send(`error inserting customer <a href=\'/'>click to go back to home page</a>`)
    }
    else{
      res.send(`succeed inserting customer <a href=\'/customer'>click to go back to customer page</a>`)
    }
  })
})
app.post('/deletecus', async(req , res)=>{
  var cusid = req.body.cust_id
  pool.query(`DELETE FROM customer WHERE cid = '${cusid}'`, (err,result)=>{
    if(err){
      res.send(`error deleting customer <a href=\'/'>click to go back to home page</a>`)
    }
    else{
      res.send(`succeed deleting customer <a href=\'/customer'>click to go back to customer page</a>`)
    }
  })
})
app.get('/contain_rest', async(req, res) => {
  var res_list = {data: []}
  res.render('pages/contain_rest',res_list)
})
app.get('/customer', (req, res) => {
  pool.query(`SELECT * FROM customer`, (err, result)=> {
    if(err){
      throw(err)
    }
    else{
      var res_list = {data: result.rows}
      //console.log(res_list.data)
      res.render('pages/customer', res_list)
    }
  })
})
app.get('/manager', (req, res) => res.render('pages/manager'))
app.get('/store', (req, res) => res.render('pages/store'))
app.get('/transaction', (req, res) => res.render('pages/transaction'))
app.get('/worker', (req, res) => res.render('pages/worker'))
app.get('/staff', (req, res) => res.render('pages/staff'))
app.get('/others', (req, res) => res.render('pages/others'))
app.get('/rest_staff', (req, res) => {
  pool.query(`SELECT * FROM restaurant_staff`, (err, result)=> {
    if(err){
      throw(err)
    }
    else{
      var res_list = {data: result.rows}
      //console.log(res_list.data)
      res.render('pages/rest_staff', res_list)
    }
  })
})
app.get('/rest_table', (req, res) => {
  pool.query(`SELECT * FROM restaurant`, (err, result)=> {
    if(err){
      throw(err)
    }
    else{
      var res_list = {data: result.rows}
      //console.log(res_list.data)
      res.render('pages/rest', res_list)
    }
  })

})

app.get('/mana', (req, res) => {
  pool.query(`SELECT * FROM manager`, (err, result)=> {
    if(err){
      throw(err)
    }
    else{
      var res_list = {data: result.rows}
      //console.log(res_list.data)
      res.render('pages/mana', res_list)
    }
  })
})
app.get('/mana_loc', (req, res) => {
  pool.query(`SELECT * FROM manager_loc`, (err, result)=> {
    if(err){
      throw(err)
    }
    else{
      var res_list = {data: result.rows}
      //console.log(res_list.data)
      res.render('pages/mana_loc', res_list)
    }
  })
})
app.get('/sales_mana', (req, res) => {
  pool.query(`SELECT * FROM sales_manager`, (err, result)=> {
    if(err){
      throw(err)
    }
    else{
      var res_list = {data: result.rows}
      //console.log(res_list.data)
      res.render('pages/sales_mana', res_list)
    }
  })
})
app.get('/storee', (req, res) => {
  
  pool.query(`SELECT sid, name FROM store`, (err, result)=> {
    if(err){
      throw(err)
    }
    else{
      var res_list = {data: result.rows}
      //console.log(res_list.data)
      res.render('pages/storee', res_list)
    }
  })
})
app.get('/store_staff', (req, res) => {
  pool.query(`SELECT * FROM store_staff`, (err, result)=> {
    if(err){
      throw(err)
    }
    else{
      var res_list = {data: result.rows}
      //console.log(res_list.data)
      res.render('pages/store_staff', res_list)
    }
  })
})
app.get('/trans_info', (req, res) => {
  pool.query(`SELECT * FROM transaction_info`, (err, result)=> {
    if(err){
      throw(err)
    }
    else{
      var res_list = {data: result.rows}
      //console.log(res_list.data)
      res.render('pages/trans_info', res_list)
    }
  })
})
app.get('/trans_ship_info', (req, res) => {
  pool.query(`SELECT * FROM trans_shipping_info`, (err, result)=> {
    if(err){
      throw(err)
    }
    else{
      var res_list = {data: result.rows}
      //console.log(res_list.data)
      res.render('pages/trans_ship_info', res_list)
    }
  })
})
app.get('/worker_info', (req, res) => {
  pool.query(`SELECT * FROM woker_info`, (err, result)=> {
    if(err){
      throw(err)
    }
    else{
      var res_list = {data: result.rows}
      //console.log(res_list.data)
      res.render('pages/worker_info', res_list)
    }
  })
})

app.get('/worker_job', (req, res) => {
  pool.query(`SELECT * FROM worker_job`, (err, result)=> {
    if(err){
      throw(err)
    }
    else{
      var res_list = {data: result.rows}
      //console.log(res_list.data)
      res.render('pages/worker_job', res_list)
    }
  })
})
app.get('/stafff', (req, res) => {
  pool.query(`SELECT * FROM staff`, (err, result)=> {
    if(err){
      throw(err)
    }
    else{
      var res_list = {data: result.rows}
      //console.log(res_list.data)
      res.render('pages/stafff', res_list)
    }
  })
})
app.get('/normal_staff', (req, res) => {
  pool.query(`SELECT * FROM normal_staff`, (err, result)=> {
    if(err){
      throw(err)
    }
    else{
      var res_list = {data: result.rows}
      //console.log(res_list.data)
      res.render('pages/normal_staff', res_list)
    }
  })
})
app.get('/goods', (req, res) => {
  pool.query(`SELECT * FROM goods`, (err, result)=> {
    if(err){
      throw(err)
    }
    else{
      var res_list = {data: result.rows}
      //console.log(res_list.data)
      res.render('pages/goods', res_list)
    }
  })
})
app.get('/principal', (req, res) => {
  pool.query(`SELECT * FROM principal`, (err, result)=> {
    if(err){
      throw(err)
    }
    else{
      var res_list = {data: result.rows}
      //console.log(res_list.data)
      res.render('pages/principal', res_list)
    }
  })
})
app.get('/depart_info', (req, res) => {
  pool.query(`SELECT * FROM depart_info`, (err, result)=> {
    if(err){
      throw(err)
    }
    else{
      var res_list = {data: result.rows}
      //console.log(res_list.data)
      res.render('pages/depart_info', res_list)
    }
  })
})
app.listen(PORT, () => console.log(`Listening on ${ PORT }`))
  